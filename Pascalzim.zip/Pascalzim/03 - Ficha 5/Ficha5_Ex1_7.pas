Program Ficha5_Ex1_7 ;
var P,C,H:real;
	
Begin

	textcolor(Yellow);
  
  
  writeln('Quantos cent�metros?');
  readln(C);
  clrscr;
  
  P:= C/2.54;


  writeln('Em polegas �: ', P:0:2);
  
  readln;
  
End.