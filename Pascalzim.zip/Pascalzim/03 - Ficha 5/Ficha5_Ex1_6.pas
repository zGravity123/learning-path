Program Ficha5_Ex1_6 ;
var V,H,D:real;
	
Begin

	textcolor(Yellow);
  
  
  writeln('Quanto tempo foi gasto? (horas)');
  readln(H);
  clrscr;
  writeln('Qual a dist�ncia percorrida? (km)');
  readln(D);
  clrscr;
  
  V:= D/H;


  writeln('A velocidade m�dia �: ', V:2:0, 'km/h');
  
  readln;
  
End.