program Ficha6_Ex2_8;
var
  a,b,c: real;

begin
  
  textcolor(Yellow);
  writeln('Introduza 3 n�meros');;
  readln(a,b,c);
  clrscr;

	if (a + b > c) and (a + c > b) and (b + c > a) then
	begin
	
	  clrscr;
  	writeln('� um tri�ngulo');
  
  	if (a = b) and (b = c) then
    	writeln('Tri�ngulo Equil�tero')
  	else if (a = b) or (a = c) or (b = c) then
    	writeln('Tri�ngulo Is�sceles')
  	else
    	writeln('Tri�ngulo Escaleno');
end

	else
  	writeln('N�o � um tri�ngulo');


  
  readln;
end.


