Program Ficha6_Ex2_1 ;
var n:integer;
Begin

	textcolor(Yellow);
	 writeln('Introduza um n�mero');
	 readln(n);
		if (n mod 2) = 0 then
			writeln('O n�mero introduzido � par')
		else
			writeln('O n�mero introduzido � impar');
		readkey;
  
End.