program Ficha6_Ex2_7;
var
  a,b,c,delta,raiz1,raiz2: real;

begin
  
  textcolor(Yellow);
  writeln('Digite os coeficientes da equa��o do segundo grau:');
  write('a: ');
  readln(a);
  write('b: ');
  readln(b);
  write('c: ');
  readln(c);

  if a = 0 then
  begin
    writeln('O coeficiente "a" n�o pode ser zero');
    halt;
  end;

  delta := b*b - 4*a*c;
  
  if delta > 0 then
  begin
    raiz1 := (-b + sqrt(delta)) / (2*a);
    raiz2 := (-b - sqrt(delta)) / (2*a);
    writeln('As ra�zes reais s�o: ', raiz1:0:2, ' e ', raiz2:0:2);
  end
  else if delta = 0 then
  begin
    raiz1 := -b / (2*a);
    writeln('A raiz real �: ', raiz1:0:2);
  end
  else
  begin
    writeln('N�o existem ra�zes reais!');
  end;
  
  readln;
end.


