Program Ficha6_Ex2_2 ;
var n1,n2:integer;
Begin

	textcolor(Yellow);
	 writeln('Introduza dois n�meros distintos');
	 readln(n1,n2);
		if (n1 > n2) then
			writeln('O n�mero maior �: ',n1)
		else
			writeln('O n�mero maior �: ',n2);
		readkey;
  
End.