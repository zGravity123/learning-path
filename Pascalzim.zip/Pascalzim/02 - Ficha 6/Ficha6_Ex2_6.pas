program Ficha6_Ex2_6;
var
  med,tt,t:real;

begin
  textcolor(Yellow);
  writeln('Escreva a nota do trabalho e do teste');
  readln(tt, t);
  clrscr;
  
  med := (tt + t) / 2;
  
  if med >= 7 then
  begin
    textcolor(Green);
    writeln('Est�s aprovado! A sua media �: ', med:0:2);
  end
  
  else if med < 3 then
  begin
    textcolor(Red);
    writeln('Est�s reprovado! A sua media �: ', med:0:2);
  end
  
  else
  begin
    textcolor(Blue);
    writeln('Est�s reprovado e de recupera��o! A sua media �: ', med:0:2);
  end;
end.
