Program Ex7 ;

var num:integer;
  
Begin

	writeln('Introduza um valor');
	readln(num);
	writeln('O quadrado do n�mero inserido �: ', num*num);
	writeln('O dobro do n�mero inserido �: ', num*2);
	readkey;
	
End.