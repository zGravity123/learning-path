Program Pzim;
var
    nome: array[1..3] of string;
    qtd: array[1..3] of integer;
    qtm: array[1..3] of integer;
    pcu: array[1..3] of real;
    encomendas: array[1..3] of real;
    i, qntpedido, produtoIndex: integer;
    nomeproduto: string;
    prosseguir: char;
    total: real;
Begin
    randomize;
    textcolor(cyan);
    
    // Dados de produtos
    
    for i := 1 to 3 do
    begin
        writeln('Digite o nome do produto #',i);
        readln(nome[i]);
        clrscr;
        
        writeln('Digite a quantidade dispon�vel (#',i,')');
        readln(qtd[i]);
        clrscr;

        writeln('Digite a quantidade m�nima necess�ria no estoque (#',i,')');
        readln(qtm[i]);
        clrscr;

        writeln('Digite o pre�o unit�rio (#',i,')');
        readln(pcu[i]);
        clrscr;
    end;

    // Processo da compra
    
    repeat
        writeln('Digite o nome do produto que deseja comprar');
        readln(nomeproduto);
        
        clrscr;
        
        produtoIndex := -1;
        for i := 1 to 3 do
        begin
            if nome[i] = nomeproduto then
            begin
                produtoIndex := i;
                break;
            end;
        end;

        if produtoIndex = -1 then
        begin
            writeln('Produto n�o encontrado!');
            clrscr;
        end;
        
        if qtd[produtoIndex] <= qtm[produtoIndex] then
            writeln('� necess�rio realizar uma nova encomenda para garantir a quantidade m�nima de estoque')
        else
        begin
        		clrscr;
            writeln('Quantas unidades deseja comprar?');
            readln(qntpedido);


            if qtd[produtoIndex] < qntpedido then
                writeln('Quantidade insuficiente no estoque. O m�ximo dispon�vel � ', qtd[produtoIndex])
                
            else
            begin
                
                encomenda[i] := pcu[produtoIndex] * qntpedido;
                clrscr;
                
                writeln('O pre�o do produto � de $$ ', encomenda[i]:0:2);
								writeln('');
                writeln('Deseja prosseguir?');
                writeln('[S]im ou [N]�o');
                readln(prosseguir);

                if (prosseguir = 'S') or (prosseguir = 's') then
                begin
                    qtd[produtoIndex] := qtd[produtoIndex] - qntpedido;
                    clrscr;
                    writeln('Produto comprado! O ID dele �: ', random(10743));
                    writeln('Estoque atualizado: ', qtd[produtoIndex], ' unidades restantes.');
                end
                else
                    writeln('Compra cancelada.');
            end;
        end;

        writeln('Deseja realizar outra compra? [S]im / [N]�o');
        readln(prosseguir);

    until (prosseguir = 'N') or (prosseguir = 'n');

end.
