Program Ex12;

Var Resultado, R: real; // Declara��o das vari�veis: R para o raio

Begin
  writeln('Introduza o Raio');
  readln(R); 

  resultado := 3.1416 * (R * R); // Calcula a �rea

  writeln('A �rea �: ', resultado:0:2); 
  readkey; 
End.
