Program Ex4 ;
Begin

  writeln('S�rgio Almeida');
  readkey;
  
End.
