Program EX24 ;
var num:integer;

Begin
  
	writeln('introduza um valor inteiro');
	readln(num);
	
	if (num = 0) then
	 writeln('O valor inteiro � zero')
	 
	else
	  writeln('O valor � Diferente de Zero');
	  
	  readkey;                                																					
  
End.