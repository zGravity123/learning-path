Program Ex10 ;

var L1, L2:integer;
  
Begin

	writeln('Introduza o lado 1 e o lado 2');
	readln(L1, L2);
	writeln('A ar�a do retangulo inserido �: ', L1*L2);
	readkey;
	
End.