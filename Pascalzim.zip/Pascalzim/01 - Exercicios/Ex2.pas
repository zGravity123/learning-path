Program Ex2 ;
Begin

  write('Ol� Mundo!');
  readkey;
  
End.
