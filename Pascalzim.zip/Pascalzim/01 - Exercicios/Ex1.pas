Program Ex1 ;
Begin

  write('Ol� Mundo!');
  
End.
