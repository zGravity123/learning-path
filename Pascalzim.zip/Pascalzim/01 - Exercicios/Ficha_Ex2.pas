Program Ficha_Ex2;
var
  A, B, P: integer;
begin
  writeln('Introduza Dois valores inteiros');
  readln(A, B);
  writeln('Escolha uma das op�oes:');
  writeln('1: Adi��o');
  writeln('2: Subtra��o');
  writeln('3: Divis�o');
  writeln('4: Multiplica��o');
  readln(P);

  if (P = 1) then
    writeln('Resultado: ', A + B);
    
  if (P = 2) then
    writeln('Resultado: ', A - B);
  if (P = 3) then
    writeln('Resultado: ', A / B);                  
  if (P = 4) then
    writeln('Resultado: ', A * B);
  
  if (P < 1) or (P > 4) then
    writeln('Opera��o Inv�lida');
  
  readkey;
end.
