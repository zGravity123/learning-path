Program Pzim ;
var m:integer;

	
procedure contas;
	Begin
	if (m = 0) then
			writeln('� zero');
	if (m mod 2 <> 0) then
			writeln('� impar');
	if (m mod 2 = 0) then
			writeln('� par');	
	end;
	
procedure ler_dados;
	Begin
		writeln('Digite um valor');
		readln(m);	
	End;
	
Begin
   
	 ler_dados;                                      
	 contas;
	 readkey;
   
End.