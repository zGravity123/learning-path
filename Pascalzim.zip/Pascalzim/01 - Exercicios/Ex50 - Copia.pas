Program Ex50;

var num:integer;

Begin
  
  num:=1;
  
  while (num <=10) do
  	begin
  	writeln('S�rgio');
  	num:=num+ 1;
  end;

  readkey;
End.
