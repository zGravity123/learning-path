Program Ex28 ;
var N:integer;
Begin

	writeln('Escreva um n�mero');
	readln(n);
	if (n mod 2 = 0) then
		writeln('O n�mero � par')
	else
		writeln('Impar');
	readkey;


 
End.