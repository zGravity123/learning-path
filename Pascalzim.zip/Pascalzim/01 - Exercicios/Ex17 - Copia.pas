Program Ex17 ;
Begin

	writeln('__________  _________.___              _________                   .__');
  writeln('\______   \/   _____/|   |            /   _____/ ___________  ____ |__| ____  ');
  writeln(' |     ___/\_____  \ |   |   ______   \_____  \_/ __ \_  __ \/ ___\|  |/  _ \ ');
  writeln(' |    |    /        \|   |  /_____/   /        \  ___/|  | \/ /_/  >  (  <_> )');
  writeln(' |____|   /_______  /|___|           /_______  /\___  >__|  \___  /|__|\____/ ');
  writeln('                  \/                         \/     \/     /_____/            ');
	writeln;
	writeln('Caracter ASCII n.65 ', chr(66)); //  Exibe o caracter correspondente ao c�digo ASCII 66, que � o 'B'. A fun��o 'chr(66)' converte o n�mero 66 para o caractere 'B'.
	writeln;
	writeln('N. ASCII do caracter A = ', ord('a')); // Exibe o n�mero ASCII do caractere 'a'. A fun��o 'ord('a')' retorna o c�digo ASCII do caractere 'a', que � 97.
	writeln;
	writeln('Antes de A est� ', Pred('A')); // Exibe o caractere que vem antes de 'A' na tabela ASCII. A fun��o 'Pred('A')' retorna o caractere imediatamente anterior a 'A', que � 'Z'.
	writeln;
	writeln('Depois de A est� ', Succ('A'));      // mostra oq vem depois do 'A'
	readkey;
		
  
End.