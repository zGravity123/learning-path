Program Ex9 ;

var l:integer;
  
Begin

	writeln('Introduza do lado');
	readln(L);
	writeln('A ar�a do quadrado inserido �: ', L*L);
	readkey;
	
End.