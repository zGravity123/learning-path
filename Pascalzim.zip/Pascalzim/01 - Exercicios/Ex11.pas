Program Ex12 ;

var A, B:integer;
	med  :real;
  
Begin

	writeln('Introduza o dois n�meros');
	readln(A, B);
	med:=(A+B)/2;
	
	writeln('A media �: ', med);
	writeln('A media �: ', med:0:2); // Casas decimais: o valor '2' exibe duas casas ap�s a v�rgula (ex.: 5.00), enquanto o padr�o original mostra seis (ex.: 5.000000)
	readkey;
	                               
End.