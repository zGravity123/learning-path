Program Ex44 ;
var C,F:real;
					             //5 bolas com os numeros at� 50 e duas estrelas at� 12
					
Begin

	textcolor(Yellow);
	writeln('Introduza a temperatura em graus C�');
	readln(C);
	
	F := 9 * C/5 + 32;
	
	clrscr;
	writeln(C:0:2, ' C� covertidos para graus �: ',F:0:2,'�F');
	readkey;
		
End.         