Program Pzim ;
var vv,par,impar:integer;

procedure ler_dados;
	Begin
		writeln('Digite um valor');
		readln(vv);	
	End;
	
procedure contas;
	Begin
		if (vv mod 2 = 0) then
			writeln('� par')
		else
			writeln('� impar');	
	end;
	
Begin
   
	 ler_dados;
	 contas;
	 readkey;
   
End.