Program Ex18 ;

var P:real;
Begin

	writeln('__________  _________.___              _________                   .__');
  writeln('\______   \/   _____/|   |            /   _____/ ___________  ____ |__| ____  ');
  writeln(' |     ___/\_____  \ |   |   ______   \_____  \_/ __ \_  __ \/ ___\|  |/  _ \ ');
  writeln(' |    |    /        \|   |  /_____/   /        \  ___/|  | \/ /_/  >  (  <_> )');
  writeln(' |____|   /_______  /|___|           /_______  /\___  >__|  \___  /|__|\____/ ');
  writeln('                  \/                         \/     \/     /_____/            ');
	writeln;
	writeln('Quanto custa o produto?');
	readln(P);
	P:= p*0.23+p;
	writeln('O pre�o do produto com iva �: ', P:0:2);
	readkey;
		
  
End.