Program Ex3 ;
Begin

  write('S�rgio Almeida');
  readkey;
  
End.
