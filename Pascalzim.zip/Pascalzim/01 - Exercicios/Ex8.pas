Program Ex8 ;

var num1, num2:integer;
  
Begin

	writeln('Introduza dois valores');
	readln(num1, num2);
	writeln('A adi��o do n�mero inserido �: ', num1+num2);
	writeln('A subtra��o do n�mero inserido �: ', num1-num2);
	writeln('A divis�o do n�mero inserido �: ', num1/num2);
	writeln('A multiplica��o do n�mero inserido �: ', num1*num2);
	readkey;
	
End.