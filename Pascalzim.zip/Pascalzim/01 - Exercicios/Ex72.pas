Program Pzim ;
var
    n, i, soma: integer;
Begin
		textcolor(Cyan);
    writeln('Digite um n�mero');
    readln(n);
    clrscr;
    
    soma := 0;

    for i := 1 to n do
        soma := soma + i;
    
    writeln('A soma dos n�meros de 1 at� ', n, ' �: ', soma);
    
    readkey; 
End.