Program Pzim ;
var num:integer;

procedure lerdados;
Begin
	writeln('Introduza um valor');
	readln(num);
end;

Begin
	
	lerdados;
	
	writeln('O n�mero introduzido pelo procedimento foi ',num);
	
	num := num * 2;
	
	writeln('O n�mero introduzido e manipulado � ',num);
  
End.