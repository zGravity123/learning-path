PROCEDURE mensagem(mensagem: string ; n: INTEGER);
VAR i: INTEGER;
BEGIN
FOR i := 1 TO n DO
WRITELN(mensagem);
END;
BEGIN
mensagem('Ol� Aluno!', 3);
END.