Program Ex7;
VAR n, resultado: INTEGER;
FUNCTION fatorial(x: INTEGER): INTEGER;
BEGIN
IF x = 0 THEN
fatorial := 1
ELSE
fatorial := x * fatorial(x - 1);
END;
BEGIN
WRITE('Digite um n�mero para calcular o fatorial: ');
READLN(n);
resultado := fatorial(n);
WRITELN('Fatorial de ', n, ' �: ', resultado);
END.