Program Ex3;
VAR a, b, soma: INTEGER;
FUNCTION somar(x: integer; y: integer): integer;
BEGIN
somar := x + y;
END;
BEGIN
WRITE('Digite o primeiro n�mero: ');
READLN(a);
WRITE('Digite o segundo n�mero: ');
READLN(b);
soma := somar(a, b);
WRITELN('A soma �: ', soma);
END.