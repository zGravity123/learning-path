Program Ex1;
VAR num, resultado: INTEGER;
FUNCTION quadrado(num: integer): INTEGER;
BEGIN
	quadrado := num * num;
END;
BEGIN
WRITE('Digite um n�mero: ');
READLN(num);
resultado := quadrado(num);
WRITELN('O quadrado �: ', resultado);
END.