Program R-EX5 ;
var n:integer;
Begin
  
	textcolor(Yellow);
	writeln('Introduza um n�mero');
	readln(n);
	clrscr;

	if (n mod 3 = 0) and (n mod 5 = 0) then
  	writeln('� m�ltiplo de ambos')
	else if n mod 3 = 0 then
  	writeln('� m�ltiplo de 3')
	else if n mod 5 = 0 then
  	writeln('� m�ltiplo de 5')
	else
  	writeln('N�o � m�ltiplo de nenhum');

	readkey;
	End.