program MenuOperacoes;
var
  soma1, soma2, subtracao1, subtracao2, multiplicacao1, multiplicacao2, op: Integer;

begin
  repeat
  clrscr;
  
    textcolor(Cyan);
    writeln(' -- Menu Interativo -- ');
    writeln('');
    writeln('Selecione uma das op��es abaixo:');
    writeln('');
    writeln('1: Somar dois n�meros');
    writeln('2: Subtrair dois n�meros');
    writeln('3: Multiplicar dois n�meros');
    writeln('');
    writeln('0: Fechar Menu');
    readln(op);
    clrscr;

    case op of
      1: begin
           writeln('Introduza dois n�meros');
           readln(soma1);  
           readln(soma2); 
           clrscr;
           writeln('O resultado da soma �: ', soma1 + soma2:2:0);
           readkey;
         end;
      
      2: begin
           writeln('Introduza dois n�meros');
           readln(subtracao1);  
           readln(subtracao2);
           writeln('O resultado da subtra��o �: ', subtracao1 - subtracao2:2:0);
           readkey;
         end;

      3: begin
           writeln('Introduza dois n�meros');
           readln(multiplicacao1);  
           readln(multiplicacao2); 
           writeln('O resultado da multiplica��o �: ', multiplicacao1 * multiplicacao2:2:0);
           readkey;
         end;

      0: begin
           writeln('Fechando o menu.');
           delay(250);
           clrscr;
           writeln('Fechando o menu..');
           delay(250);
           clrscr;
           writeln('Fechando o menu...');
           delay(250);
           clrscr;
           break; 
         end;

    else
      writeln('Op��o inv�lida! Tente novamente');
      readkey;
    end;

  until op = 0;  
end.
