Program Pzim ;
var soma,med,a,b,c:real;
Begin
  
  textcolor(Yellow);
  writeln('Introduza 10 n�meros');
  readln(a,b,c);
  soma:= a+b+c;
  med:=a;
	clrscr;
	writeln('A soma �:', soma:2:0);
	writeln('A media �:', med:2:0);
	readkey; 
End.