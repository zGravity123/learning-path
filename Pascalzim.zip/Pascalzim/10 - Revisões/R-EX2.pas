Program Pzim ;
var e:real;
Begin
  
  textcolor(Yellow);
  writeln('Quantos euros s�o?');
  readln(e);
	clrscr;
	writeln('S�o ',e*100:0:2,' centimos');
	readkey; 
End.