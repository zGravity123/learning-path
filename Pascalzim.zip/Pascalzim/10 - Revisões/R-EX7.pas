Program Pzim ;
var n,i: integer;

Begin
 textcolor(Yellow);
  Writeln('Digite um n�mero N: ');
  Readln(N);

  for i := 1 to N do
    Writeln(i);
  	
  Readln;
End.