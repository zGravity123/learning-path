Program Pzim ;
var v,cont,soma:Integer;
		med:real;
Begin
	
	textcolor(cyan);
	repeat 
		writeln('Introduza sucessivamente n�meros inteiros positivos');
		readln(v);
		clrscr;
		
		cont := cont + 1;
		soma := soma + v;
		
	until v = 0;
	
		med := soma/cont;
	
	writeln('Foram introduzidos ',cont,'n�meros!');
	writeln('A soma de todos os n�meros �: ',soma);
	writeln('A m�dia de todos os n�meros �: ',med:0:2);
  
End.