Program Pzim ;
var n:integer;
Begin
	textcolor(Yellow);
	
   writeln('Introduza um valor valido');
   readln(n);
   clrscr;
   if (n>= 0) and (n<=10) then
   	writeln('Valor v�lido')
  else
  	writeln('Valo inv�lido');
  readkey;
  	
End.