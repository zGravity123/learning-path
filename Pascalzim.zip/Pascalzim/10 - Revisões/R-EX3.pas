Program Pzim ;
var a,b,c,maior:real;
Begin
  
	textcolor(Yellow);
	writeln('Introduza 3 n�meros');
	readln(a, b, c);
	clrscr;

	 maior := a;

	if b > maior then
 	 maior := b;

	if c > maior then
 	 maior := c;

	writeln('O maior n�mero �: ', maior:0:2);
	readkey;
	End.