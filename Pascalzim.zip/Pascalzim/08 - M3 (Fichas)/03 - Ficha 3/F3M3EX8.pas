Program Pzim ;
var op,fr:string;
		vogais, i:integer;
		

label home;

Begin
 home:
 	clrscr;
  textcolor(cyan);
  writeln('Digite uma frase');
  readln(fr);
  
  
  for i := 1 to length(fr) do
  	Begin
  		if (fr[i] = 'a') or(fr[i] = 'e') or (fr[i] = 'i') or (fr[i] = 'o') or (fr[i] = 'u') then
  		 Begin
  		  write(' ');
  		 end
  		 
  		else
  		 begin
  			write(fr[i]);
  		 end;
  	end;
   readkey;
   clrscr;
  
  
  writeln('Deseja reniciar o Progama?');
  writeln('      [S]im ou [N]�o      ');
  readln(op);
  
  op := upcase(op);
  
  if (op = 'S') then
   goto home
  else
  	
End.