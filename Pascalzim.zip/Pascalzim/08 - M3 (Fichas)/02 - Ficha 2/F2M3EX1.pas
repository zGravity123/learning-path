Program Pzim;
label home;
var op, home: string;
    a, b: real;

Begin
home:
  textcolor(Cyan);

	clrscr;
	writeln('Digite dois n�meros');
	readln(a,b);
	clrscr;
	
	writeln('A m�dia aritm�tica �: ', (a + b)/2:0:2);
	readkey;

  clrscr;

  writeln('Pressione "A" se quiser reiniciar o programa, caso n�o, pressione "B"');
  readln(op);
  op := upcase(op);

  if (op = 'A') then
    goto home
  else
  begin
    clrscr;
    writeln('Saindo do programa.');
    delay(250);
    clrscr;
    writeln('Saindo do programa..');
    delay(250);
    clrscr;
    writeln('Saindo do programa...');
    delay(250);
  end;

End.
