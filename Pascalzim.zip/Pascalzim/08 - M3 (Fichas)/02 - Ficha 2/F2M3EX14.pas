program Pzim;

var
  num, i, fatorial: Integer;

begin
  Write('Digite um n�mero: ');
  ReadLn(num);

  fatorial := 1;

  for i := 1 to num do
  begin
    fatorial := fatorial * i;
  end;

  WriteLn('O fatorial de ', num, ' �: ', fatorial);
end.
