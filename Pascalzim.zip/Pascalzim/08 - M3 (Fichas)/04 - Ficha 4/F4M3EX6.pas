Program Pzim ;
var op:string;
		nn:integer;

label home;
Begin
home:
	 textcolor(Cyan);
   writeln('Digite um n�mero inteiro');
   readln(nn);
   
   if (nn > 0) then
   	writeln('O n�mero introduzido � inteiro');
   if (nn < 0) then
   	writeln('0 n�mero introduzido � negativo');
   if (nn = 0) then
   	writeln('O n�mero introduzido � zero')
   else
   
  clrscr; 
  writeln('Deseja reniciar o Progama?');
  writeln('      [S]im ou [N]�o      ');
  readln(op);
  
  op := upcase(op);
  
  if (op = 'S') then
   goto home
  else
  
End.