Program Pzim ;
label home;
var op,home:string;
		la,cm,ptlp,area,ptn,lm:real;
Begin
   home:
   textcolor(Cyan);
   
   	writeln('Digite a Largura');
   	readln(la);
   	clrscr;
   	
   	writeln('Digite o Comprimento (em metros)');
   	readln(cm);
   	clrscr;
   	
   	writeln('Qual a pot�ncia da l�mpada (w)');
   	readln(ptlp);
    clrscr;
    
   		area := la * cm;
   		ptn := area * 18;  // Potencia Total Necessaria
   		lm := ptn/ptlp; // Numero de lampada
   
		writeln('Ser�o necess�rias ', lm:2:0, ' l�mpadas para iluminar a �rea informada');
		readkey;
	
		clrscr;
  	writeln('Pressione "A" se quiser reiniciar o programa, caso n�o, pressione "B"');
  	readln(op);
  	op := upcase(op);

  if (op = 'A') then
    goto home 

  else 
  begin
    clrscr;
    writeln('Saindo do programa.');
    delay(250);
    clrscr;
    writeln('Saindo do programa..');
    delay(250);
    clrscr;
    writeln('Saindo do programa...');
    delay(250);
  end;
	 
	 
   
  
  
  
End.