Program Pzim ;
var i:integer;
		mdt:array[1..3] of integer;

Begin
  textcolor(Cyan);
  for i := 1 to 3 do
  begin
  	writeln('Quais s�o as medidas dos tr�s lados do Tri�ngulo? (lado #',i,')');
  	readln(mdt[i]);
  end;
  
  if (mdt[1] = mdt[2]) and (mdt[2] = mdt[3]) then
  	clrscr;
  	writeln('O Tri�ngulo � equil�tero');
  	
  if ((mdt[1] = mdt[2]) and (mdt[1] <> mdt[3])) or
     ((mdt[1] = mdt[3]) and (mdt[1] <> mdt[2])) or
   	 ((mdt[2] = mdt[3]) and (mdt[1] <> mdt[2])) then
   	clrscr;
  	writeln('O Tri�ngulo � Is�sceles');
  if (mdt[1] <> mdt[2]) and (mdt[1] <> mdt[3]) and (mdt[2] <> mdt[3]) then
  	clrscr;
		writeln('Tri�ngulo Escaleno');
 readkey; 
End.
