program ficha_2;

uses crt, math;

var N, resultado: real;
    S: char;

begin
	textcolor(Yellow);
  writeln('Introduza "R" para raiz quadrada ou "Q" para o quadrado: ');
  readln(S);
  clrscr;
  S := upcase(S); 

  if (S = 'R') or (S = 'Q') then
  
  begin
    writeln('Introduza um n�mero (diferente de zero): ');
    readln(N);

    while N = 0 do
    begin
      writeln('Erro: o n�mero n�o pode ser ZERO:');
      readln(N);
    end;

    if S = 'Q' then
    begin
      resultado := N * N;
      writeln('O quadrado de ', N:0:2, ' � ', resultado:0:2);
    end;

    if S = 'R' then
    begin
      resultado := sqrt(N);
      writeln('A raiz quadrada de ', N:0:2, ' � ', resultado:0:2);
    end;
  end
  
  else
    writeln('Op��o inv�lida!');

  readkey;
end.
